%% LAB6- IRISH MEHTA
% 2017AAPS0295G


%% Filter Design
Fs = 1000;  % Sampling Frequency

N    = 50;       % Order
Fc   = 200;      % Cutoff Frequency
flag = 'scale';  % Sampling Flag

% Create the window vector for the design algorithm.
win = rectwin(N+1);

% Calculate the coefficients using the FIR1 function.
b  = fir1(N, Fc/(Fs/2), 'low', win, flag);



%% Assignment


clc;
fc=50;%frequency of the carrier
n = 0:50;
fs=1000;
t=0:1/fs:(1-1/fs);
x=1*sin(2*pi*80*t);
x2=1*sin(2*pi*250*t)
x_noisy = x + x2;
y= filter(b,1,x_noisy);

subplot(3,2,1)
plot(t,x_noisy); %plot the signal
title('Noise Signal, Sum of two Sinusodial signals'); xlabel('Time index n'); ylabel('x[n]');

subplot(3,2,2);
N=1000; %FFT size;
X = fft(x_noisy,N);
df=fs/N; %frequency resolution
sampleIndex = 0:N-1; %raw index for FFT plot
f=sampleIndex*df; %x-axis index converted to frequencies
stem(f,abs(X)/500); %x-axis represent frequencies
title('Spectrum Noisy Signal'); xlabel('Freq in Hz'); ylabel('Magnitude');
xlim([0 500]);
ylim([0 2]);

subplot(3,2,3)
plot(t,y, 'r');
title('Filtered Signal'); xlabel('Time index n'); ylabel('x[n]');

subplot(3,2,4);
N=1000; %FFT size;
X = fft(y,N);
df=fs/N; %frequency resolution
sampleIndex = 0:N-1; %raw index for FFT plot
f=sampleIndex*df; %x-axis index converted to frequencies
stem(f,abs(X)/500); %x-axis represent frequencies
title('Spectrum Filtered Signal'); xlabel('Freq in Hz'); ylabel('Magnitude');
xlim([0 500]);
ylim([0 2]);

subplot(3,2,5)
stem(n,b);
title('Filter Co-efficients'); xlabel('Time index n'); ylabel('x[n]');
xlim([0 50]);

subplot(3,2,6)
[h,w]= freqz(b,1);
plot(w*fs/(2*pi),20*log10(abs(h)));
title('Filter Response'); xlabel('Freq in Hz'); ylabel('Magnitude in dB');
xlim([0 500]);